(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_layout_tsx_b4714161._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_layout_tsx_b4714161._.js",
  "chunks": [
    "static/chunks/node_modules_@tanstack_query-devtools_build_99a50d1b._.js",
    "static/chunks/node_modules_9f8bf54e._.js",
    "static/chunks/src_components_74e784ba._.js",
    "static/chunks/[root of the server]__29bb49f1._.css"
  ],
  "source": "dynamic"
});
