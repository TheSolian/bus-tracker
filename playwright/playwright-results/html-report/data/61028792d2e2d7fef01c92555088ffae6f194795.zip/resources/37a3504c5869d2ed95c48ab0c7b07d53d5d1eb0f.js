(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_(root)_page_tsx_ec633843._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_(root)_page_tsx_ec633843._.js",
  "chunks": [
    "static/chunks/src_cea7fcb5._.js",
    "static/chunks/node_modules_axios_lib_99999129._.js",
    "static/chunks/node_modules_@mui_system_esm_9208743a._.js",
    "static/chunks/node_modules_@mui_material_esm_aaf3ee34._.js",
    "static/chunks/node_modules_@tanstack_table-core_build_lib_index_mjs_dc7bc5d7._.js",
    "static/chunks/node_modules_zod_lib_index_mjs_ee760afb._.js",
    "static/chunks/node_modules_a4b537cd._.js"
  ],
  "source": "dynamic"
});
