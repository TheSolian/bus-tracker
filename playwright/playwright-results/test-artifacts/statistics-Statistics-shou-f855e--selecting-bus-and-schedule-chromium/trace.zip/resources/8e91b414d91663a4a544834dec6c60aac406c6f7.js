(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/node_modules_@tanstack_query-devtools_build_DevtoolsComponent_SUXNJKMM_cd6015b5.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/node_modules_@tanstack_query-devtools_build_DevtoolsComponent_SUXNJKMM_cd6015b5.js",
  "chunks": [
    "static/chunks/node_modules_@tanstack_query-devtools_build_089cd3b0._.js"
  ],
  "source": "dynamic"
});
