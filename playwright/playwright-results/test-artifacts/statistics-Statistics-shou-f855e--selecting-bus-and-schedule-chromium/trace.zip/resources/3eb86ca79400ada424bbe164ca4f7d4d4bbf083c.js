(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_(root)_statistics_page_tsx_e79a55ac._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_(root)_statistics_page_tsx_e79a55ac._.js",
  "chunks": [
    "static/chunks/node_modules_axios_lib_99999129._.js",
    "static/chunks/node_modules_lodash_68adb183._.js",
    "static/chunks/node_modules_recharts_es6_0408da1d._.js",
    "static/chunks/node_modules_a11478ed._.js",
    "static/chunks/src_c9537f05._.js"
  ],
  "source": "dynamic"
});
